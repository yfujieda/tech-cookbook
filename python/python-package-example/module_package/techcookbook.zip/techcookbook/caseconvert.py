"""
module to convert the strings to either lowercase or uppercase
"""

def to_lowercase(given_strings):
    """"convert given strings to lower case"""
    return given_strings.lower()

def to_uppercase(given_strings):
    """"convert given strings to upper case"""
    return given_strings.upper()
