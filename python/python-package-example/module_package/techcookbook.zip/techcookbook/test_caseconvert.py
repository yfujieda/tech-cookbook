from caseconvert import *

my_string = "hello, how are you doing Mike?"

print(to_uppercase(my_string))
print(to_lowercase(my_string))